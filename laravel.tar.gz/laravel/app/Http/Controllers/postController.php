<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class postController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function getPost($id)
    {
        $post = app/Post::where('id','=',$id)->get;
        $comments = app/Comment::where('post_id','=',$id)->get;

        return view('post',compact('post','comments'));
    }

}
